<!DOCTYPE html>
<html lang="es">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>DevsWebs</title>
    <link rel="icon" type="image/png" href="images/IconoDevsWebs.png"> <!-- Le asigna un ícono a la página en la pestaña del navegador-->
    <link rel="stylesheet" href="css/estiloGeneral.css">
    <link rel="stylesheet" href="css/estiloContacto.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Crimson+Pro&family=Roboto">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <link type="text/css" rel="stylesheet" href="css/tailwind.min.css"  media="screen,projection"/>
</head>


<body>

    <div id="contenedorSitio">

        <div id = "header">
            <header>
                <div class="contenedorSuperior">
                    <ul>
                        <li>
                             <!-- <img src="images/Icono.png" width="50" height="50">-->
                             <div id="foto">
                
                            </div>
                        </li>
                        <li>
                            <h1 class="tituloPagina">DevsWebs</h1>
                        </li>
                        <li class="btn-sesion">
                        <a href="index.php" id="inicioSesion">
                                Iniciar Sesión
                            </a>
                            <a href="register.php" id="inicioSesion">
                                Registrarme
                            </a>
                        </li>
                    </ul>
                </div>
            </header>
        </div>

        <div id="navegador">
            <nav class="menuPaginaPrincipal">                
                <div class="contenedorMenu">
                    <ul>
                        <li>
                            <a href="home.php">Inicio</a>
                        </li>
                        <li>
                            <a href="servicios.php">Servicios</a>
                        </li>
                        <li>
                            <a href="quienes-somos.php">¿Quiénes somos?</a>
                        </li>
                        <li>
                            <a href="contacto.php">Contacto</a>
                        </li>
                    </ul>
                </div>            
            </nav>
        </div>
        <div class="contenedor">
            <div id="textoContacto">
                <h3>Si tiene alguna consulta, queja o propuesta, puede realizarlo por este medio y lo atenderemos lo mas pronto posible.</h3>
            </div>
            <div class="container mx-auto mt-20 bg-FFC886">     
                      
                <form id="enviar-mail" class="py-10 px-5 max-w-lg mx-auto">
                    <div class="mb-10">
                        <label for="email">Email:</label>
                        <input class="bg-gray-100 border shadow p-3 w-full"  id="email" type="email">
                    </div>
                    <div class="mb-10">
                        <label for="asunto">Asunto:</label>
                        <input class="bg-gray-100 border shadow p-3 w-full"  id="asunto" type="text">
                    </div>
                    <div class="mb-10"> 
                        <label for="mensaje">Mensaje:</label>
                        <textarea class="bg-gray-100 border shadow p-3 w-full" id="mensaje"></textarea>
                    </div>
        
                    <div  id="spinner">
                        <div class="sk-chase">
                            <div class="sk-chase-dot"></div>
                            <div class="sk-chase-dot"></div>
                            <div class="sk-chase-dot"></div>
                            <div class="sk-chase-dot"></div>
                            <div class="sk-chase-dot"></div>
                            <div class="sk-chase-dot"></div>
                        </div>
                    </div>
                    
                    <div class="flex justify-between">
                            <button 
                                id="enviar" class="w-full bg-blue-600 px-2 py-5 text-white items-center  mr-5 uppercase font-bold items-center flex justify-center" 
                                type="submit" 
                            >Enviar

                            </button>
        
                            <button 
                                id="resetBtn" 
                                class="w-full bg-green-600 px-2 py-5 text-white items-center uppercase font-bold items-center flex justify-center" 
                                type="button"
                            >Borrar
                                    
                            </button>
                    </div>
                </form> 
            </div>
        </div>
    </div>
    <div id="espacio_naranja"></div>

    <div id="footer">
            <footer>
                <div class="rrss">
                    <a class="btn" href="https://www.facebook.com/DevsWebs-101371318467191" target="_blank">
                      <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="btn" href="https://twitter.com/WebsDevs" target="_blank">
                      <i class="fab fa-twitter"></i>
                    </a>
                    <a class="btn" href="https://www.instagram.com/devswebs/?hl=es-la" target="_blank">
                      <i class="fab fa-instagram"></i>
                    </a>
                </div>
                <div id="messenger" >
                    <a href="https://m.me/101371318467191" target="_blank">
                        <img src="images/iconoMessenger.png" width="150px" height="100px">
                    </a>
                </div>
            </footer>
        </div>    
    <script src="js/script.js"></script>
</body>

</html>