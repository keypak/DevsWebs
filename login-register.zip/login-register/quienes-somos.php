<!DOCTYPE html>
<html lang="es">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>DevsWebs</title>
    <link rel="icon" type="image/png" href="images/IconoDevsWebs.png"> <!-- Le asigna un ícono a la página en la pestaña del navegador-->
    <link rel="stylesheet" href="css/estiloGeneral.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Crimson+Pro&family=Roboto">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <link rel="stylesheet" href="css/estiloQuienes-Somos.css">
</head>

<body>

    <div id="contenedorSitio">

        <div id = "header">
            <header>
                <div class="contenedorSuperior">
                    <ul>
                        <li>
                             <!-- <img src="images/Icono.png" width="50" height="50">-->
                             <div id="foto">
                
                            </div>
                        </li>
                        <li>
                            <h1 class="tituloPagina">DevsWebs</h1>
                        </li>
                        <li class="btn-sesion">
                            <a href="index.php" id="inicioSesion">
                                Iniciar Sesión
                            </a>
                            <a href="register.php" id="inicioSesion">
                                Registrarme
                            </a>
                        </li>
                    </ul>
                </div>
            </header>
        </div>

        <div id="navegador">
            <nav class="menuPaginaPrincipal">                
                <div class="contenedorMenu">
                    <ul>
                    <li>
                            <a href="home.php">Inicio</a>
                        </li>
                        <li>
                            <a href="servicios.php">Servicios</a>
                        </li>
                        <li>
                            <a href="quienes-somos.php">¿Quiénes somos?</a>
                        </li>
                        <li>
                            <a href="contacto.php">Contacto</a>
                        </li>
                    </ul>
                </div>            
            </nav>
        </div>
        <div class="contenedor">
            <h2 class="titulo"> Pensamos, diseñamos y programamos </h2>
            <p class="parrafo">
                Somos un grupo de estudiantes conformado por cuatro personas que se encargan de desarrollar y diseñar paginas webs.
                Pero no solo son paginas webs comunes; nos encargamos que tú pagina deje una marca en las personas, que se acuerden de tu empresa. Todo esto gracias al estilo unico y atractivo que posee pagina. 
                Al ser 4 personas tenemos habilidades diferentes y nos dedicamos a explotar esa habilidad en cada sector de la pagina, evitando crear una pagina cuadrada y aburrida. Lo cual se ve reflejado en el diseño final, ahi vas a encontrar una codificacion ordenada y pura;
                acompañada de un diseño esplendido, basado en los gustos actuales de las personas. A todo esto le sumamos los estandares de los clientes, ya que cumplimos con sus requisitos, y ademas les agregamos recomendaciones para que la pagina sea mas fructuosa.
                <section id="perfiles">
                    <section class="uno">
                        <img src="images/Joaquín.png" width="290" height="290">
                        <p class="descripcion">Vásquez, Joaquin: Maquetado de pagina, Logica de pagina y testing</p>
                    </section>
                    <section class="uno dos">
                        <img src="images/Jorge.png" width="290" height="290" >
                        <p class="descripcion2">Antequera, Jorque: Desarrollo Front-End</p>
                    </section>
                    <section class="uno tres">
                        <img src="images/Nahuel.png" width="290" height="290" >
                        <p class="descripcion3">Diaz, Nahuel: Desarrollo Back-End</p>
                    </section>
                    <section class="uno cuatro">
                        <img src="images/Carolina.png" width="290" height="290">
                        <p class="descripcion4">Mallón, Carolina: Diseño de pagina, Diseño de interfaz de usuario y marketing</p>
                    </section>
                </section>
                
            </p>
            
        </div>
        
        <div id="footer">
            <footer>
                <div class="rrss">
                    <a class="btn" href="https://www.facebook.com/DevsWebs-101371318467191" target="_blank">
                      <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="btn" href="https://twitter.com/WebsDevs" target="_blank">
                      <i class="fab fa-twitter"></i>
                    </a>
                    <a class="btn" href="https://www.instagram.com/devswebs/?hl=es-la" target="_blank">
                      <i class="fab fa-instagram"></i>
                    </a>
                </div>
                <div id="messenger" >
                    <a href="https://m.me/101371318467191" target="_blank">
                        <img src="images/iconoMessenger.png" width="150px" height="100px">
                    </a>
                </div>
            </footer>
        </div>    
    </div>
    <script src="js/script.js"></script>
</body>

</html>