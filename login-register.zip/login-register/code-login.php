<?php

// Incluir archivo de conexion a la base de datos
include('conexion.php');

// Definir variable e inicializar con valores vacio
$usuario=$_POST['usuario'];
$contrasena=$_POST['contrasena'];
session_start();
$_SESSION['usuario']=$usuario;

// VALIDANDO INPUT DE NOMBRE DE USUARIO Y CONTRASENA
$conexion=mysqli_connect("localhost","root","","login_register_db");

$consulta="SELECT*FROM usuarios where usuario='$usuario' and contrasena='$contrasena'";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_num_rows($resultado);

if($filas){
  
    header("location:home.php");

}else{
    ?>
  <?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);
?>