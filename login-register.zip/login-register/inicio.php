<!DOCTYPE html>
<html lang="es">
<head> <!-- Se indica al sitio web caracteristicas y atributos-->
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"> <!-- Se indica que el sitio sea compatible con paginas que no cumpla con los estandares de un sitio web-->
    <meta charset="UTF-8"> <!--Se utiliza para soportar diversos caracteres-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> <!-- Hace que la pagina sea responsivo-->
    <title>DevsWebs</title> <!--Le asigna un título a la página en la pestaña del navegador-->
    <link rel="icon" type="image/png" href="images/IconoDevsWebs.png"> <!-- Le asigna un ícono a la página en la pestaña del navegador-->
    <link rel="stylesheet" href="css/estiloGeneral.css"> <!--Hacemos referencia al archivo que contendra el diseño y estilo de las paginas en general-->
    <link rel="stylesheet" href="css/estiloInicio.css"><!--Hacemos referencia al archivo que contendra el diseño y estilo de esta página-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Crimson+Pro&family=Roboto"> <!-- Insertamos una tipografía-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css"> <!-- Utilizaremos un framework para el uso de íconos e imágenes -->
</head>

<body> <!--Se indica que contendra el sitio web para la visualizacion del usuario-->

    <div id="contenedorSitio"> <!-- Identificaremos al contendor para tener mayor precision de su diseño -->

        <div id = "header"> <!-- Creamos una seccion que se ubicara en la parte superior de la pagina-->
            <header>
                <!-- <label id="inicioSesion"><input type="button" value="Iniciar Sesión / Registrarme"></label> -->
                               
                <div class="contenedorSuperior">
                    <ul>
                        <li>
                             <!-- <img src="images/Icono.png" width="50" height="50">-->
                             <div id="foto">
                
                            </div>
                        </li>
                        <li>
                            <h1 class="tituloPagina">DevsWebs</h1>
                        </li>
                        <li class="btn-sesion">
                            <a href="index.php" id="inicioSesion">
                                Iniciar Sesión
                            </a>
                            <a href="register.php" id="inicioSesion">
                                Registrarme
                            </a>
                        </li>
                    </ul>
                </div>
            </header>
        </div>

        <div id="navegador">
            <nav class="menuPaginaPrincipal">                
                <div class="contenedorMenu">
                    <ul>
                    <li>
                            <a href="inicio.php">Inicio</a>
                        </li>
                        <li>
                            <a href="servicios.php">Servicios</a>
                        </li>
                        <li>
                            <a href="quienes-somos.php">¿Quiénes somos?</a>
                        </li>
                        <li>
                            <a href="contacto.php">Contacto</a>
                        </li>
                    </ul>
                </div>            
            </nav>
        </div>
        <div class="contenedor">
            <h1 id="titulo">Devs Webs</h1>
            <h2 id="subtitulo">¡Crea tu propia página!</h2>
            <div class="cuadro">
                <div class="contenedorTexto" style="float: left;" >En la plataforma puedes crear una página web sin invertir mucho tiempo y no necesitas conocer nada sobre diseño ya que podemos hallarte la solución.</div> 
                <div class="contenedorImagen">
                    <img src="images/imagen1Inicio.PNG" width="400px" height="200px">
                </div>
            </div>
            <div class="cuadro">
                <div class="contenedorImagen">
                    <img src="images/imagen2Inicio.PNG" width="400px" height="200px">
                </div>
                <div class="contenedorTexto" style="float: left;" >DevsWebs es una plataforma donde podrás crear tu propia página web, blog o tienda online no será necesario que sepas de programacion para diseñar tu sitio online.</div> 
            </div>
            <div class="cuadro">
                <div class="contenedorTexto" style="float: left;">Para poder crear tu página sólo debes registrarte, nos comunicamos con vos para ajustar los detalles, responder un par de preguntas con tus preferencias y comenzar a crear.</div> 
                <div class="contenedorImagen">
                    <img src="images/imagen3Inicio.png" width="400px" height="200px">
                </div>
            </div>
            <div class="cuadro">
                <div class="contenedorImagen">
                    <img src="images/imagen4Inicio.png" width="50%" height="50%">
                </div>
                <div class="contenedorTexto" style="float: left;">Tienes la opción de que DevsWebs cree una página web para ti con sólo un click.</div> 
                
            </div>
            <div class="cuadro">
                <div class="contenedorTexto" style="float: left;">En la plataforma puedes crear una página web sin invertir mucho tiempo y no necesitas conocer nada sobre diseño ya que podemos hallarte la solución.</div> 
                <div class="contenedorImagen">
                    <img src="images/imagen5Inicio.PNG" width="400px" height="200px">
                </div>
            </div>
            <div class="cuadro">
                <div class="contenedorImagen">
                    <img src="images/imagen6Inicio.PNG" width="400px" height="200px">
                </div>
                <div class="contenedorTexto" style="float: left;">Pero si eres alguien con un poco de experiencia y prefieres hacer una desde el inicio y con sólo una base, nos contactaremos para adaptarnos a tus ideas.</div> 
                
            </div>

            <div id="espacio_naranja">
                
            </div>

        </div>
        <div id="footer">
            <footer>
                <div class="rrss">
                    <a class="btn" href="https://www.facebook.com/DevsWebs-101371318467191" target="_blank">
                      <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="btn" href="https://twitter.com/WebsDevs" target="_blank">
                      <i class="fab fa-twitter"></i>
                    </a>
                    <a class="btn" href="https://www.instagram.com/devswebs/?hl=es-la" target="_blank">
                      <i class="fab fa-instagram"></i>
                    </a>
                </div>
                <div id="messenger" >
                    <a href="https://m.me/101371318467191" target="_blank">
                        <img src="images/iconoMessenger.png" width="150px" height="100px">
                    </a>
                </div>
            </footer>
        </div>    
    </div>
    <script src="js/script.js"></script>
</body>

</html>