<?php
    
    // Incluir archivo de conexion a la base de datos
    require_once "conexion.php";
    
    // Definir variable e inicializar con valores vacio
    $usuario = $correo= $contrasena= "";
    $usuario_err = $correo_err = $contrasena_err = "";
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        
        // VALIDANDO INPUT DE NOMBRE DE USUARIO
        if(empty(trim($_POST["usuario"]))){
            $usuario_err = "Por favor, ingrese un nombre de usuario";
        }else{
            //prepara una declaracion de seleccion
            $sql = "SELECT id FROM usuarios WHERE usuario = ?";
            
            if($stmt = mysqli_prepare($conexion, $sql)){
                mysqli_stmt_bind_param($stmt, "s", $param_usuario);
                
                $param_usuario = trim($_POST["usuario"]);
                
                if(mysqli_stmt_execute($stmt)){
                    mysqli_stmt_store_result($stmt);
                    
                    if(mysqli_stmt_num_rows($stmt) == 1){
                        $usuario_err = "Este nombre de usuario ya está en uso";
                    }else{
                        $usuario = trim($_POST["usuario"]);
                    }
                }else{
                    echo "Ups! Algo salió mal, inténtalo mas tarde";
                }
            }
        }
        
        
        // VALIDANDO INPUT DE EMAIL
        if(empty(trim($_POST["correo"]))){
            $correo_err = "Por favor, ingrese un correo";
        }else{
            //prepara una declaracion de seleccion
            $sql = "SELECT id FROM usuarios WHERE correo = ?";
            
            if($stmt = mysqli_prepare($conexion, $sql)){
                mysqli_stmt_bind_param($stmt, "s", $param_correo);
                
                $param_correo = trim($_POST["correo"]);
                
                if(mysqli_stmt_execute($stmt)){
                    mysqli_stmt_store_result($stmt);
                    
                    if(mysqli_stmt_num_rows($stmt) == 1){
                        $correo_err = "Este correo ya está en uso";
                    }else{
                        $correo = trim($_POST["correo"]);
                    }
                }else{
                    echo "Ups! Algo salió mal, inténtalo mas tarde";
                }
            }
        }
        
        
        // VALIDANDO CONTRASEÑA
        if(empty(trim($_POST["contrasena"]))){
            $contrasena_err = "Por favor, ingrese una contraseña";
        }elseif(strlen(trim($_POST["contrasena"])) < 4){
            $contrasena_err = "La contraseña debe de tener al menos 4 caracteres";
        } else{
            $contrasena = trim($_POST["contrasena"]);
        }
        
        
        // COMPROBANDO LOS ERRORES DE ENTRADA ANTES DE INSERTAR LOS DATOS EN LA BASE DE DATOS
        if(empty($usuario_err) && empty($correo_err) && empty($contrasena_err)){
            
            $sql = "INSERT INTO usuarios (usuario, correo, contrasena) VALUES (?, ?, ?)";
            
            if($stmt = mysqli_prepare($conexion, $sql)){
                mysqli_stmt_bind_param($stmt, "sss", $param_usuario, $param_correo, $param_contrasena);
                
                // ESTABLECIENDO PARAMETRO
                $param_usuario = $usuario;
                $param_correo = $correo;
                $param_contrasena = $contrasena;
                
                
                if(mysqli_stmt_execute($stmt)){
                    header("location: index.php");
                }else{
                    echo "Algo Salio mal, intentalo despues";
                }
            }
        }
        
        mysqli_close($conexion);
        
    }
    
?>