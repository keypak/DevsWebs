<?php
    require "code-login.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login - Devs Webs</title>
    <link rel="stylesheet" href="css/estilos.css">

    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
</head>

<body>

    <div class="container-all">
        <div class="ctn-form">
        <h1 class="titulo">Devs Webs</h1>
            <h2 class="subtitulo">Iniciar Sesión</h2>

            <form action="code-login.php" method="post">
    
            <label for="">Nombre de Usuario</label>
            <input type="text" name="usuario">
            <label for="">Contraseña</label>
            <input type="password" name="contrasena">

            <input type="submit" value="Ingresar">

            </form>

            <span class="text-footer">¿Aún no te has regsitrado?
            <a href="register.php">Registrate</a>
            </span>
        </div>

        <div class="ctn-text">
        <div class="capa"></div>
        <h1 class="title-description">Devs Webs</h1>
        <p class="text-description">Creamos la pagina que necesites</p>
        </div>

    </div>

</body>

</html>

