<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DevsWebs</title>
  <link rel="icon" type="image/png" href="images/IconoDevsWebs.png"> <!-- Le asigna un ícono a la página en la pestaña del navegador-->
  <link rel="stylesheet" href="css/estiloServicios.css">
  <link rel="stylesheet" href="css/estiloGeneral.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Crimson+Pro&family=Roboto">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
</head>
<body>
  <div id="contenedorSitio">

    <div id = "header">
        <header>
          <div class="contenedorSuperior">
            <ul>
                <li>
                     <!-- <img src="images/Icono.png" width="50" height="50">-->
                     <div id="foto">
        
                    </div>
                </li>
                <li>
                    <h1 class="tituloPagina">DevsWebs</h1>
                </li>
                <li class="btn-sesion">
                <a href="index.php" id="inicioSesion">
                                Iniciar Sesión
                            </a>
                            <a href="register.php" id="inicioSesion">
                                Registrarme
                            </a>
                </li>
            </ul>
        </div>
        </header>
    </div>

    <div id="navegador">
        <nav class="menuPaginaPrincipal">                
            <div class="contenedorMenu">
                <ul>
                <li>
                            <a href="home.php">Inicio</a>
                        </li>
                        <li>
                            <a href="servicios.php">Servicios</a>
                        </li>
                        <li>
                            <a href="quienes-somos.php">¿Quiénes somos?</a>
                        </li>
                        <li>
                            <a href="contacto.php">Contacto</a>
                        </li>
                </ul>
            </div>            
        </nav>
    </div>
    <div class="contenedor">
      <div class="tablaPrecios">
        <div class="tarjetaPrecios">
          <h3 class="encabezadotarjetaPrecios">Personal</h3>
          <div class="precio"><sup>$</sup>15<span>/Mes</span></div>
          <ul>
            <li><strong>3</strong> Paginas Webs</li>
            <li><strong>20 GB</strong> Almacenamiento en Base de datos</li>
            <li><strong>1</strong> Nombre de dominio</li>
            <li><strong>5</strong> Email</li>
            <li><strong>10 Hs</strong> Asesoramiento</li>
          </ul>
          <a href="#" class="botonOrden">Comprar</a>
        </div>
      
        <div class="tarjetaPrecios">
          <h3 class="encabezadotarjetaPrecios">Profesional</h3>
          <div class="precio"><sup>$</sup>50<span>/Mes</span></div>
          <ul>
            <li><strong>10</strong> Paginas Webs</li>
            <li><strong>50 GB</strong> Almacenamiento en Base de datos</li>
            <li><strong>1</strong> Nombre de dominio</li>
            <li><strong>20</strong> Email</li>
            <li><strong>10 Hs</strong> Asesoramiento</li>
          </ul>
          <a href="#" class="botonOrden">Comprar</a>
        </div>
      
        <div class="tarjetaPrecios">
          <h3 class="encabezadotarjetaPrecios">PyMES</h3>
          <div class="precio"><sup>$</sup>75<span>/Mes</span></div>
          <ul>
            <li><strong>30</strong> Paginas Webs</li>
            <li><strong>150 GB</strong> Almacenamiento en Base de Datos</li>
            <li><strong>1</strong> Nombre de dominio</li>
            <li><strong>40</strong> Email</li>
            <li><strong>20 Hs</strong> Asesoramiento</li>
          </ul>
          <a href="#" class="botonOrden">Comprar</a>
        </div>
      
        <div class="tarjetaPrecios">
          <h3 class="encabezadotarjetaPrecios">Empresas</h3>
          <div class="precio"><sup>$</sup>100<span>/Mes</span></div>
          <ul>
            <li><strong>100</strong> Paginas Webs</li>
            <li><strong>500 GB</strong> Almacenamiento en Base de Datos</li>
            <li><strong>1</strong> Nombre de dominio</li>
            <li><strong>100</strong> Email</li>
            <li><strong>40 Hs</strong> Asesoramiento</li>
          </ul>
          <a href="#" class="botonOrden">Comprar</a>
        </div>
      </div>
      
    </div>
    <div id="footer">
        <footer>
          <div class="rrss">
            <a class="btn" href="https://www.facebook.com/DevsWebs-101371318467191" target="_blank">
              <i class="fab fa-facebook-f"></i>
            </a>
            <a class="btn" href="https://twitter.com/WebsDevs" target="_blank">
              <i class="fab fa-twitter"></i>
            </a>
            <a class="btn" href="https://www.instagram.com/devswebs/?hl=es-la" target="_blank">
              <i class="fab fa-instagram"></i>
            </a>
          </div>
          <div id="messenger" >
            <a href="https://m.me/101371318467191" target="_blank">
                <img src="images/iconoMessenger.png" width="150px" height="100px">
            </a>
        </div>
        </footer>
    </div>    
</div>
<script src="js/script.js"></script>
 
</body>
</html>


